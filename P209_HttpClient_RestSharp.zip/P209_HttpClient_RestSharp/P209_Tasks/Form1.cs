﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Windows.Forms;
using RestSharp;
using P209_Tasks.Model;
using System.Diagnostics;

namespace P209_Tasks
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSynchronous_Click(object sender, EventArgs e)
        {
            Stopwatch sp = new Stopwatch();
            sp.Start();

            lboxSynchornous.Items.Clear();
            var ids = GetCitiesId();

            foreach (var id in ids)
            {
                var weather = LoadWeather(id);
                lboxSynchornous.Items.Add($"City: {weather.city.name}; Description: {weather.list[0].weather[0].description}");
            }

            sp.Stop();
            lblSynInfo.Text = $"Finished in {sp.ElapsedMilliseconds} ms";
            lblSynInfo.Visible = true;
        }

        public WeatherResponse LoadWeather(string id)
        {
            var client = new RestClient("https://api.openweathermap.org/data/2.5/forecast");
            var request = new RestRequest($"?appid=ad13347afe18e1b76716899dc1747aa8&id={id}", Method.GET);
            WeatherResponse weather = client.Execute<WeatherResponse>(request).Data;

            return weather;
        }

        private async void btnAsynchronous_Click(object sender, EventArgs e)
        {
            lboxAsynchronous.Items.Clear();
            Stopwatch sp = new Stopwatch();
            sp.Start();

            var ids = GetCitiesId();

            foreach (var id in ids)
            {
                Task<WeatherResponse> resultTask = Task.Run(() =>
                {
                    return LoadWeather(id);
                });

                //do whatever you want that doesn't depend on weather
                lblAsyncInfo.Visible = true;
                lblAsyncInfo.Text = $"Currrenly loading city with id: {id}";

                WeatherResponse weather = await resultTask;
                lboxAsynchronous.Items.Add($"City: {weather.city.name}; Description: {weather.list[0].weather[0].description}");
            }

            sp.Stop();
            lblAsyncInfo.Text = $"Finished in {sp.ElapsedMilliseconds} ms";
        }

        private async void btnParalel_Click(object sender, EventArgs e)
        {
            lboxParalel.Items.Clear();
            Stopwatch sp = new Stopwatch();
            sp.Start();

            var ids = GetCitiesId();

            List<Task<WeatherResponse>> tasks = new List<Task<WeatherResponse>>();

            //fill 
            foreach (var id in ids)
            {
                tasks.Add(new Task<WeatherResponse>(() =>
                {
                    return LoadWeather(id);
                }));
            }

            foreach (var task in tasks)
            {
                task.Start();
            }

            WeatherResponse[] results = await Task.WhenAll(tasks);

            foreach (var weather in results)
            {
                lboxParalel.Items.Add($"City: {weather.city.name}; Description: {weather.list[0].weather[0].description}");
            }

            sp.Stop();
            lblParalelInfo.Text = $"Finished in {sp.ElapsedMilliseconds} ms";
            lblParalelInfo.Visible = true;
        }

        public string[] GetCitiesId()
        {
            return new string[] { "148251", "147425", "587342", "409420", "585103", "585030", "585184", "148251", "147425",
                "587342", "409420", "585103", "585030", "585184",  "148251", "147425", "587342", "409420", "585103", "585030", "585184", "148251", "147425",
                "587342", "409420", "585103", "585030", "585184", "148251", "147425", "587342", "409420", "585103", "585030", "585184", "148251", "147425",
                "587342", "409420", "585103", "585030", "585184",  "148251", "147425", "587342", "409420", "585103", "585030", "585184", "148251", "147425",
                "587342", "409420", "585103", "585030", "585184" };
        }
    }
}
