﻿namespace P209_Tasks
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.btnSynchronous = new System.Windows.Forms.Button();
            this.lboxSynchornous = new System.Windows.Forms.ListBox();
            this.lboxAsynchronous = new System.Windows.Forms.ListBox();
            this.btnAsynchronous = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.lboxParalel = new System.Windows.Forms.ListBox();
            this.btnParalel = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.lblAsyncInfo = new System.Windows.Forms.Label();
            this.lblSynInfo = new System.Windows.Forms.Label();
            this.lblParalelInfo = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Comic Sans MS", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(104, 66);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(209, 45);
            this.label1.TabIndex = 0;
            this.label1.Text = "Synchronous";
            // 
            // btnSynchronous
            // 
            this.btnSynchronous.BackColor = System.Drawing.Color.Teal;
            this.btnSynchronous.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSynchronous.Font = new System.Drawing.Font("Century Gothic", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSynchronous.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnSynchronous.Location = new System.Drawing.Point(112, 136);
            this.btnSynchronous.Name = "btnSynchronous";
            this.btnSynchronous.Size = new System.Drawing.Size(632, 131);
            this.btnSynchronous.TabIndex = 1;
            this.btnSynchronous.Text = "Synchronous";
            this.btnSynchronous.UseVisualStyleBackColor = false;
            this.btnSynchronous.Click += new System.EventHandler(this.btnSynchronous_Click);
            // 
            // lboxSynchornous
            // 
            this.lboxSynchornous.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lboxSynchornous.FormattingEnabled = true;
            this.lboxSynchornous.ItemHeight = 34;
            this.lboxSynchornous.Location = new System.Drawing.Point(112, 333);
            this.lboxSynchornous.Name = "lboxSynchornous";
            this.lboxSynchornous.Size = new System.Drawing.Size(632, 752);
            this.lboxSynchornous.TabIndex = 2;
            // 
            // lboxAsynchronous
            // 
            this.lboxAsynchronous.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lboxAsynchronous.FormattingEnabled = true;
            this.lboxAsynchronous.ItemHeight = 34;
            this.lboxAsynchronous.Location = new System.Drawing.Point(828, 333);
            this.lboxAsynchronous.Name = "lboxAsynchronous";
            this.lboxAsynchronous.Size = new System.Drawing.Size(632, 752);
            this.lboxAsynchronous.TabIndex = 5;
            // 
            // btnAsynchronous
            // 
            this.btnAsynchronous.BackColor = System.Drawing.Color.Teal;
            this.btnAsynchronous.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAsynchronous.Font = new System.Drawing.Font("Century Gothic", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAsynchronous.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnAsynchronous.Location = new System.Drawing.Point(828, 136);
            this.btnAsynchronous.Name = "btnAsynchronous";
            this.btnAsynchronous.Size = new System.Drawing.Size(632, 131);
            this.btnAsynchronous.TabIndex = 4;
            this.btnAsynchronous.Text = "Asynchronous";
            this.btnAsynchronous.UseVisualStyleBackColor = false;
            this.btnAsynchronous.Click += new System.EventHandler(this.btnAsynchronous_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Comic Sans MS", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(828, 66);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(226, 45);
            this.label2.TabIndex = 3;
            this.label2.Text = "Asynchronous";
            // 
            // lboxParalel
            // 
            this.lboxParalel.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lboxParalel.FormattingEnabled = true;
            this.lboxParalel.ItemHeight = 34;
            this.lboxParalel.Location = new System.Drawing.Point(1547, 333);
            this.lboxParalel.Name = "lboxParalel";
            this.lboxParalel.Size = new System.Drawing.Size(632, 752);
            this.lboxParalel.TabIndex = 8;
            // 
            // btnParalel
            // 
            this.btnParalel.BackColor = System.Drawing.Color.Teal;
            this.btnParalel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnParalel.Font = new System.Drawing.Font("Century Gothic", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnParalel.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnParalel.Location = new System.Drawing.Point(1547, 136);
            this.btnParalel.Name = "btnParalel";
            this.btnParalel.Size = new System.Drawing.Size(632, 131);
            this.btnParalel.TabIndex = 7;
            this.btnParalel.Text = "Paralel";
            this.btnParalel.UseVisualStyleBackColor = false;
            this.btnParalel.Click += new System.EventHandler(this.btnParalel_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Comic Sans MS", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(1539, 66);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(201, 45);
            this.label3.TabIndex = 6;
            this.label3.Text = "Paralel Task";
            // 
            // lblAsyncInfo
            // 
            this.lblAsyncInfo.AutoSize = true;
            this.lblAsyncInfo.Font = new System.Drawing.Font("Century Gothic", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAsyncInfo.Location = new System.Drawing.Point(821, 1102);
            this.lblAsyncInfo.Name = "lblAsyncInfo";
            this.lblAsyncInfo.Size = new System.Drawing.Size(233, 39);
            this.lblAsyncInfo.TabIndex = 9;
            this.lblAsyncInfo.Text = "Asynchronous";
            this.lblAsyncInfo.Visible = false;
            // 
            // lblSynInfo
            // 
            this.lblSynInfo.AutoSize = true;
            this.lblSynInfo.Font = new System.Drawing.Font("Century Gothic", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSynInfo.Location = new System.Drawing.Point(105, 1102);
            this.lblSynInfo.Name = "lblSynInfo";
            this.lblSynInfo.Size = new System.Drawing.Size(233, 39);
            this.lblSynInfo.TabIndex = 10;
            this.lblSynInfo.Text = "Asynchronous";
            this.lblSynInfo.Visible = false;
            // 
            // lblParalelInfo
            // 
            this.lblParalelInfo.AutoSize = true;
            this.lblParalelInfo.Font = new System.Drawing.Font("Century Gothic", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblParalelInfo.Location = new System.Drawing.Point(1540, 1102);
            this.lblParalelInfo.Name = "lblParalelInfo";
            this.lblParalelInfo.Size = new System.Drawing.Size(233, 39);
            this.lblParalelInfo.TabIndex = 11;
            this.lblParalelInfo.Text = "Asynchronous";
            this.lblParalelInfo.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2267, 1302);
            this.Controls.Add(this.lblParalelInfo);
            this.Controls.Add(this.lblSynInfo);
            this.Controls.Add(this.lblAsyncInfo);
            this.Controls.Add(this.lboxParalel);
            this.Controls.Add(this.btnParalel);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lboxAsynchronous);
            this.Controls.Add(this.btnAsynchronous);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lboxSynchornous);
            this.Controls.Add(this.btnSynchronous);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Tasks";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnSynchronous;
        private System.Windows.Forms.ListBox lboxSynchornous;
        private System.Windows.Forms.ListBox lboxAsynchronous;
        private System.Windows.Forms.Button btnAsynchronous;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ListBox lboxParalel;
        private System.Windows.Forms.Button btnParalel;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblAsyncInfo;
        private System.Windows.Forms.Label lblSynInfo;
        private System.Windows.Forms.Label lblParalelInfo;
    }
}

