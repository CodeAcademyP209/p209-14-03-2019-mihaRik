﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Mvc;
using System.Threading.Tasks;
using P209_HttpClient_RestSharp.Models;
using Newtonsoft.Json;
using RestSharp;

namespace P209_HttpClient_RestSharp.Controllers
{
    public class HomeController : Controller
    {
        public async Task<ActionResult> Index()
        {
            HttpClient httpClient = new HttpClient();
            httpClient.BaseAddress = new Uri("https://api.openweathermap.org/data/2.5/forecast");
            HttpResponseMessage response = await httpClient.GetAsync("?appid=ad13347afe18e1b76716899dc1747aa8&id=627535");

            if (response.IsSuccessStatusCode)
            {
                string content = await response.Content.ReadAsStringAsync();

                WeatherResponse weather = JsonConvert.DeserializeObject<WeatherResponse>(content);

                return View(weather);
            }

            return Content("API call failed.");
        }

        public async Task<ActionResult> About()
        {
            var client = new RestClient("https://api.openweathermap.org/data/2.5/forecast");
            var request = new RestRequest("?appid=ad13347afe18e1b76716899dc1747aa8&id=627535", Method.GET);
            WeatherResponse weather = (await client.ExecuteGetTaskAsync<WeatherResponse>(request)).Data;

            return View(weather);
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}